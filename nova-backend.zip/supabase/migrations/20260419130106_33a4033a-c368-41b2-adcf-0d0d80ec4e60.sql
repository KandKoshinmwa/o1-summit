-- Allow fleet members (drivers) to read the subscription row for their fleet,
-- so the driver dashboard reflects whether the fleet is active.
CREATE POLICY "Members can view fleet subscription"
ON public.subscriptions
FOR SELECT
TO authenticated
USING (is_fleet_member(auth.uid(), fleet_id));