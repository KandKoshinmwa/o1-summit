ALTER TABLE public.recommendations
ADD COLUMN IF NOT EXISTS ranked_stations jsonb;