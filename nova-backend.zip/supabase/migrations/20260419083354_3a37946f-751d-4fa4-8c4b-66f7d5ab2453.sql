
-- =========================================
-- ENUMS
-- =========================================
CREATE TYPE public.app_role AS ENUM ('DRIVER', 'FLEET_MANAGER');
CREATE TYPE public.subscription_status AS ENUM ('trialing', 'active', 'past_due', 'canceled', 'incomplete');
CREATE TYPE public.recommendation_status AS ENUM ('pending', 'accepted', 'rejected', 'expired');

-- =========================================
-- UPDATED_AT TRIGGER FUNCTION
-- =========================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- =========================================
-- PROFILES
-- =========================================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  display_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER trg_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- USER_ROLES (separate table for security)
-- =========================================
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- =========================================
-- FLEETS
-- =========================================
CREATE TABLE public.fleets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  fleet_code TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.fleets ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_fleets_owner ON public.fleets(owner_user_id);
CREATE INDEX idx_fleets_code ON public.fleets(fleet_code);

CREATE TRIGGER trg_fleets_updated_at
BEFORE UPDATE ON public.fleets
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- FLEET_MEMBERS
-- =========================================
CREATE TABLE public.fleet_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fleet_id UUID NOT NULL REFERENCES public.fleets(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (fleet_id, user_id)
);
ALTER TABLE public.fleet_members ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_fleet_members_user ON public.fleet_members(user_id);
CREATE INDEX idx_fleet_members_fleet ON public.fleet_members(fleet_id);

-- Helper: is this user a member of this fleet?
CREATE OR REPLACE FUNCTION public.is_fleet_member(_user_id UUID, _fleet_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.fleet_members
    WHERE user_id = _user_id AND fleet_id = _fleet_id
  )
$$;

-- Helper: does this user own this fleet?
CREATE OR REPLACE FUNCTION public.owns_fleet(_user_id UUID, _fleet_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.fleets
    WHERE id = _fleet_id AND owner_user_id = _user_id
  )
$$;

-- =========================================
-- RECOMMENDATIONS
-- =========================================
CREATE TABLE public.recommendations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  driver_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  fleet_id UUID REFERENCES public.fleets(id) ON DELETE SET NULL,
  origin TEXT NOT NULL,
  destination TEXT NOT NULL,
  recommended_route JSONB NOT NULL,
  recommended_fuel_stop JSONB,
  estimated_savings_usd NUMERIC(10,2) DEFAULT 0,
  score NUMERIC(6,2) DEFAULT 0,
  status public.recommendation_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.recommendations ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_recs_driver ON public.recommendations(driver_user_id);
CREATE INDEX idx_recs_fleet ON public.recommendations(fleet_id);

CREATE TRIGGER trg_recs_updated_at
BEFORE UPDATE ON public.recommendations
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- FLEET_METRICS
-- =========================================
CREATE TABLE public.fleet_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fleet_id UUID NOT NULL REFERENCES public.fleets(id) ON DELETE CASCADE,
  metric_date DATE NOT NULL DEFAULT CURRENT_DATE,
  total_miles NUMERIC(12,2) DEFAULT 0,
  fuel_saved_usd NUMERIC(12,2) DEFAULT 0,
  fuel_spent_usd NUMERIC(12,2) DEFAULT 0,
  recommendations_accepted INT DEFAULT 0,
  recommendations_rejected INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (fleet_id, metric_date)
);
ALTER TABLE public.fleet_metrics ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_metrics_fleet_date ON public.fleet_metrics(fleet_id, metric_date);

CREATE TRIGGER trg_metrics_updated_at
BEFORE UPDATE ON public.fleet_metrics
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================
-- SUBSCRIPTIONS (per fleet, $10/mo)
-- =========================================
CREATE TABLE public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fleet_id UUID NOT NULL UNIQUE REFERENCES public.fleets(id) ON DELETE CASCADE,
  owner_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  stripe_customer_id TEXT,
  stripe_subscription_id TEXT,
  status public.subscription_status NOT NULL DEFAULT 'incomplete',
  current_period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_subs_owner ON public.subscriptions(owner_user_id);
CREATE INDEX idx_subs_stripe ON public.subscriptions(stripe_subscription_id);

CREATE TRIGGER trg_subs_updated_at
BEFORE UPDATE ON public.subscriptions
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Helper: does this fleet have an active subscription?
CREATE OR REPLACE FUNCTION public.fleet_has_active_subscription(_fleet_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.subscriptions
    WHERE fleet_id = _fleet_id
      AND status IN ('active', 'trialing')
      AND (current_period_end IS NULL OR current_period_end > now())
  )
$$;

-- =========================================
-- FUEL_TRANSACTIONS (with computed 1% fee)
-- =========================================
CREATE TABLE public.fuel_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fleet_id UUID NOT NULL REFERENCES public.fleets(id) ON DELETE CASCADE,
  driver_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  recommendation_id UUID REFERENCES public.recommendations(id) ON DELETE SET NULL,
  amount_usd NUMERIC(10,2) NOT NULL,
  gallons NUMERIC(8,3),
  station_name TEXT,
  platform_fee_usd NUMERIC(10,2) GENERATED ALWAYS AS (ROUND(amount_usd * 0.01, 2)) STORED,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.fuel_transactions ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_fuel_fleet ON public.fuel_transactions(fleet_id);
CREATE INDEX idx_fuel_driver ON public.fuel_transactions(driver_user_id);

-- =========================================
-- RLS POLICIES
-- =========================================

-- profiles
CREATE POLICY "Users can view own profile" ON public.profiles
FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON public.profiles
FOR UPDATE TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" ON public.profiles
FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- user_roles
CREATE POLICY "Users can view own roles" ON public.user_roles
FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own role" ON public.user_roles
FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- fleets
CREATE POLICY "Managers can create fleets" ON public.fleets
FOR INSERT TO authenticated
WITH CHECK (auth.uid() = owner_user_id AND public.has_role(auth.uid(), 'FLEET_MANAGER'));

CREATE POLICY "Owners and members can view fleets" ON public.fleets
FOR SELECT TO authenticated
USING (
  auth.uid() = owner_user_id
  OR public.is_fleet_member(auth.uid(), id)
);

CREATE POLICY "Owners can update fleets" ON public.fleets
FOR UPDATE TO authenticated USING (auth.uid() = owner_user_id);

CREATE POLICY "Owners can delete fleets" ON public.fleets
FOR DELETE TO authenticated USING (auth.uid() = owner_user_id);

-- fleet_members
CREATE POLICY "Users can view their fleet memberships" ON public.fleet_members
FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.owns_fleet(auth.uid(), fleet_id));

CREATE POLICY "Users can join fleets" ON public.fleet_members
FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Owners or self can remove member" ON public.fleet_members
FOR DELETE TO authenticated
USING (auth.uid() = user_id OR public.owns_fleet(auth.uid(), fleet_id));

-- recommendations
CREATE POLICY "Drivers can view own recommendations" ON public.recommendations
FOR SELECT TO authenticated
USING (
  auth.uid() = driver_user_id
  OR (fleet_id IS NOT NULL AND public.owns_fleet(auth.uid(), fleet_id))
);

CREATE POLICY "Drivers can create own recommendations" ON public.recommendations
FOR INSERT TO authenticated WITH CHECK (auth.uid() = driver_user_id);

CREATE POLICY "Drivers can update own recommendations" ON public.recommendations
FOR UPDATE TO authenticated USING (auth.uid() = driver_user_id);

-- fleet_metrics
CREATE POLICY "Members and owners can view metrics" ON public.fleet_metrics
FOR SELECT TO authenticated
USING (
  public.owns_fleet(auth.uid(), fleet_id)
  OR public.is_fleet_member(auth.uid(), fleet_id)
);

-- subscriptions
CREATE POLICY "Owners can view own subscription" ON public.subscriptions
FOR SELECT TO authenticated USING (auth.uid() = owner_user_id);

-- fuel_transactions
CREATE POLICY "Drivers see own, managers see fleet" ON public.fuel_transactions
FOR SELECT TO authenticated
USING (
  auth.uid() = driver_user_id
  OR public.owns_fleet(auth.uid(), fleet_id)
);

CREATE POLICY "Drivers can insert own fuel txns" ON public.fuel_transactions
FOR INSERT TO authenticated WITH CHECK (auth.uid() = driver_user_id);

-- =========================================
-- AUTO-CREATE PROFILE ON SIGNUP
-- =========================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _role public.app_role;
BEGIN
  -- Insert profile
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'display_name', split_part(NEW.email, '@', 1))
  );

  -- Insert role from signup metadata (defaults to DRIVER)
  _role := COALESCE(
    (NEW.raw_user_meta_data ->> 'role')::public.app_role,
    'DRIVER'::public.app_role
  );

  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, _role);

  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
