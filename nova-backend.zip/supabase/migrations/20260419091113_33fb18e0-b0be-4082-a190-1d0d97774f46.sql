-- user_profiles: stores onboarding answers (vehicle, commute, preferences)
CREATE TABLE public.user_profiles (
  user_id UUID PRIMARY KEY,
  onboarding_complete BOOLEAN NOT NULL DEFAULT false,

  -- Vehicle
  vehicle_type TEXT,           -- car | suv | truck | van
  fuel_type TEXT,              -- gas | diesel | electric
  fuel_efficiency_mpg NUMERIC, -- MPG (or MPGe for EVs)

  -- Commute
  home_location TEXT,
  work_location TEXT,
  weekly_miles NUMERIC,

  -- Preferences (0-100 sliders)
  pref_cost INTEGER NOT NULL DEFAULT 50,
  pref_time INTEGER NOT NULL DEFAULT 50,
  pref_quality INTEGER NOT NULL DEFAULT 50,

  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile data"
ON public.user_profiles FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own profile data"
ON public.user_profiles FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile data"
ON public.user_profiles FOR UPDATE TO authenticated
USING (auth.uid() = user_id);

CREATE TRIGGER update_user_profiles_updated_at
BEFORE UPDATE ON public.user_profiles
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();