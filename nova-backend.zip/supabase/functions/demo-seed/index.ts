import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

const DEMO_FLEET_CODE = "DEMO24";
const DEMO_FLEET_NAME = "Demo Logistics Co";
const DEMO_KEY = "nova-demo-2024";
const DEMO_ACCOUNTS = {
  manager: { email: "manager.demo@nova.app", password: "DemoManager123!", display: "Morgan Lee (Manager)" },
  driver1: { email: "driver1.demo@nova.app", password: "DemoDriver123!", display: "Alex Rivera" },
  driver2: { email: "driver2.demo@nova.app", password: "DemoDriver123!", display: "Sam Chen" },
  driver3: { email: "driver3.demo@nova.app", password: "DemoDriver123!", display: "Jordan Patel" },
} as const;
const ALL_EMAILS = Object.values(DEMO_ACCOUNTS).map((account) => account.email);
const STATIONS = ["Shell", "Chevron", "BP", "Exxon", "Costco Fuel", "Pilot", "Loves", "Mobil"];
const ROUTES = [
  { origin: "Oakland, CA", destination: "Sacramento, CA" },
  { origin: "San Jose, CA", destination: "Fresno, CA" },
  { origin: "Los Angeles, CA", destination: "San Diego, CA" },
  { origin: "Portland, OR", destination: "Seattle, WA" },
  { origin: "Denver, CO", destination: "Colorado Springs, CO" },
  { origin: "Phoenix, AZ", destination: "Tucson, AZ" },
] as const;

const supabaseUrl = Deno.env.get("SUPABASE_URL");
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

if (!supabaseUrl || !serviceRoleKey) {
  throw new Error("Backend demo seeding is not configured correctly.");
}

const admin = createClient(supabaseUrl, serviceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

function randBetween(min: number, max: number) {
  return Math.random() * (max - min) + min;
}

function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

async function findUserIdByEmail(email: string): Promise<string | null> {
  let page = 1;
  while (page < 10) {
    const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 200 });
    if (error) throw error;
    const found = data.users.find((user) => user.email?.toLowerCase() === email.toLowerCase());
    if (found) return found.id;
    if (data.users.length < 200) return null;
    page += 1;
  }
  return null;
}

async function deleteDemoData() {
  const userIds: string[] = [];
  for (const email of ALL_EMAILS) {
    const id = await findUserIdByEmail(email);
    if (id) userIds.push(id);
  }

  const { data: fleets, error: fleetLookupError } = await admin
    .from("fleets")
    .select("id")
    .eq("fleet_code", DEMO_FLEET_CODE);

  if (fleetLookupError) throw fleetLookupError;

  const fleetIds = (fleets ?? []).map((fleet) => fleet.id);
  if (fleetIds.length > 0) {
    const deletions = await Promise.all([
      admin.from("fuel_transactions").delete().in("fleet_id", fleetIds),
      admin.from("recommendations").delete().in("fleet_id", fleetIds),
      admin.from("fleet_metrics").delete().in("fleet_id", fleetIds),
      admin.from("fleet_members").delete().in("fleet_id", fleetIds),
      admin.from("subscriptions").delete().in("fleet_id", fleetIds),
      admin.from("fleets").delete().in("id", fleetIds),
    ]);
    for (const result of deletions) {
      if (result.error) throw result.error;
    }
  }

  for (const userId of userIds) {
    const deletions = await Promise.all([
      admin.from("recommendations").delete().eq("driver_user_id", userId),
      admin.from("fuel_transactions").delete().eq("driver_user_id", userId),
      admin.from("user_profiles").delete().eq("user_id", userId),
      admin.from("user_roles").delete().eq("user_id", userId),
      admin.from("profiles").delete().eq("id", userId),
    ]);
    for (const result of deletions) {
      if (result.error) throw result.error;
    }
    const { error } = await admin.auth.admin.deleteUser(userId);
    if (error) throw error;
  }
}

async function createDemoUser(
  email: string,
  password: string,
  displayName: string,
  role: "FLEET_MANAGER" | "DRIVER",
) {
  const { data, error } = await admin.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { display_name: displayName, role },
  });
  if (error || !data.user) throw new Error(`Failed to create ${email}: ${error?.message}`);

  const { error: deleteRoleError } = await admin.from("user_roles").delete().eq("user_id", data.user.id);
  if (deleteRoleError) throw deleteRoleError;

  const { error: insertRoleError } = await admin.from("user_roles").insert({ user_id: data.user.id, role });
  if (insertRoleError) throw insertRoleError;

  return data.user.id;
}

async function seedDemo() {
  await deleteDemoData();

  const managerId = await createDemoUser(
    DEMO_ACCOUNTS.manager.email,
    DEMO_ACCOUNTS.manager.password,
    DEMO_ACCOUNTS.manager.display,
    "FLEET_MANAGER",
  );

  const driverIds: string[] = [];
  for (const key of ["driver1", "driver2", "driver3"] as const) {
    const account = DEMO_ACCOUNTS[key];
    const userId = await createDemoUser(account.email, account.password, account.display, "DRIVER");
    driverIds.push(userId);
  }

  const allUsers = [managerId, ...driverIds];
  for (let i = 0; i < allUsers.length; i += 1) {
    // Leave driver1 (index 1) mid-onboarding so the demo tour can show the
    // real onboarding screen. Manager + other drivers stay fully onboarded.
    const isDriver1 = i === 1;
    const { error } = await admin.from("user_profiles").insert({
      user_id: allUsers[i],
      onboarding_complete: !isDriver1,
      vehicle_type: i === 0 ? "Sedan" : "Box Truck",
      fuel_type: "Diesel",
      fuel_efficiency_mpg: 18 + i * 1.5,
      home_location: "Oakland, CA",
      work_location: "San Jose, CA",
      weekly_miles: 600 + i * 50,
      pref_cost: 60,
      pref_time: 30,
      pref_quality: 40,
    });
    if (error) throw error;
  }

  const { data: fleet, error: fleetError } = await admin
    .from("fleets")
    .insert({
      name: DEMO_FLEET_NAME,
      fleet_code: DEMO_FLEET_CODE,
      owner_user_id: managerId,
    })
    .select()
    .single();
  if (fleetError || !fleet) throw new Error(`Fleet: ${fleetError?.message}`);

  const { error: memberError } = await admin.from("fleet_members").insert(
    driverIds.map((userId) => ({ fleet_id: fleet.id, user_id: userId })),
  );
  if (memberError) throw memberError;

  const { error: subscriptionError } = await admin.from("subscriptions").insert({
    fleet_id: fleet.id,
    owner_user_id: managerId,
    status: "active",
    stripe_customer_id: `demo_cus_${fleet.id.slice(0, 8)}`,
    stripe_subscription_id: `demo_sub_${fleet.id.slice(0, 8)}`,
    current_period_end: new Date(Date.now() + 30 * 86400_000).toISOString(),
  });
  if (subscriptionError) throw subscriptionError;

  const now = Date.now();
  const txns = Array.from({ length: 24 }, () => {
    const gallons = randBetween(15, 55);
    const pricePerGal = randBetween(3.6, 5.2);
    const amount = +(gallons * pricePerGal).toFixed(2);
    return {
      fleet_id: fleet.id,
      driver_user_id: pick(driverIds),
      station_name: pick(STATIONS),
      gallons: +gallons.toFixed(2),
      amount_usd: amount,
      occurred_at: new Date(now - Math.floor(randBetween(0, 30)) * 86400_000).toISOString(),
    };
  });
  const { error: transactionError } = await admin.from("fuel_transactions").insert(txns);
  if (transactionError) throw transactionError;

  const acceptedSavings = [42, 38, 51, 29, 47, 33, 55, 45];
  const recs = [
    ...acceptedSavings.map((savings, i) => {
      const route = pick(ROUTES);
      return {
        driver_user_id: pick(driverIds),
        fleet_id: fleet.id,
        origin: route.origin,
        destination: route.destination,
        recommended_route: { distance_miles: 120 + i * 10, duration_min: 130 + i * 8 },
        recommended_fuel_stop: { name: pick(STATIONS), price_per_gal: 3.79 },
        estimated_savings_usd: savings,
        status: "accepted",
        score: 0.85,
      };
    }),
    ...Array.from({ length: 3 }, (_, i) => {
      const route = pick(ROUTES);
      return {
        driver_user_id: pick(driverIds),
        fleet_id: fleet.id,
        origin: route.origin,
        destination: route.destination,
        recommended_route: { distance_miles: 100, duration_min: 110 },
        recommended_fuel_stop: { name: pick(STATIONS), price_per_gal: 3.89 },
        estimated_savings_usd: 25 + i * 5,
        status: "pending",
        score: 0.78,
      };
    }),
    (() => {
      const route = pick(ROUTES);
      return {
        driver_user_id: pick(driverIds),
        fleet_id: fleet.id,
        origin: route.origin,
        destination: route.destination,
        recommended_route: { distance_miles: 90, duration_min: 100 },
        recommended_fuel_stop: { name: pick(STATIONS), price_per_gal: 4.05 },
        estimated_savings_usd: 15,
        status: "rejected",
        score: 0.62,
      };
    })(),
  ];
  const { error: recommendationError } = await admin.from("recommendations").insert(recs);
  if (recommendationError) throw recommendationError;

  return {
    ok: true,
    fleetCode: DEMO_FLEET_CODE,
    fleetId: fleet.id,
    manager: DEMO_ACCOUNTS.manager.email,
    drivers: driverIds.length,
    transactionCount: txns.length,
    recommendationCount: recs.length,
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { action, key } = await req.json();
    if (key !== DEMO_KEY) {
      return new Response(JSON.stringify({ error: "Invalid demo key" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "reset") {
      await deleteDemoData();
      return new Response(JSON.stringify({ ok: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (action === "seed") {
      const result = await seedDemo();
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: (error as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});