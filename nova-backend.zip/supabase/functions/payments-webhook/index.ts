import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { type StripeEnv, createStripeClient, verifyWebhook } from "../_shared/stripe.ts";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const url = new URL(req.url);
  const env = (url.searchParams.get("env") || "sandbox") as StripeEnv;

  try {
    const event = await verifyWebhook(req, env);
    console.log("Stripe event:", event.type, "env:", env);

    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutCompleted(event.data.object, env);
        break;
      case "customer.subscription.created":
      case "customer.subscription.updated":
        await upsertSubscription(event.data.object);
        break;
      case "customer.subscription.deleted":
        await markCanceled(event.data.object);
        break;
      default:
        console.log("Unhandled:", event.type);
    }
    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("Webhook error:", e);
    return new Response("Webhook error", { status: 400 });
  }
});

async function handleCheckoutCompleted(session: any, env: StripeEnv) {
  // For subscription mode, fetch the subscription so we can persist it
  // immediately rather than waiting on customer.subscription.created.
  if (session.mode !== "subscription" || !session.subscription) return;
  try {
    const stripe = createStripeClient(env);
    const sub = await stripe.subscriptions.retrieve(session.subscription as string);
    // Merge metadata from session if subscription is missing it
    if (!sub.metadata?.fleetId && session.metadata?.fleetId) {
      sub.metadata = { ...sub.metadata, ...session.metadata };
    }
    await upsertSubscription(sub);
  } catch (e) {
    console.error("Failed to hydrate subscription from checkout.session.completed:", e);
  }
}

async function upsertSubscription(sub: any) {
  const fleetId = sub.metadata?.fleetId;
  const userId = sub.metadata?.userId;
  if (!fleetId || !userId) {
    console.error("Missing fleetId/userId on subscription", sub.id);
    return;
  }
  const periodEnd = sub.current_period_end
    ? new Date(sub.current_period_end * 1000).toISOString()
    : null;

  await supabase.from("subscriptions").upsert(
    {
      fleet_id: fleetId,
      owner_user_id: userId,
      stripe_customer_id: sub.customer,
      stripe_subscription_id: sub.id,
      status: sub.status,
      current_period_end: periodEnd,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "fleet_id" }
  );
}

async function markCanceled(sub: any) {
  await supabase
    .from("subscriptions")
    .update({ status: "canceled", updated_at: new Date().toISOString() })
    .eq("stripe_subscription_id", sub.id);
}
