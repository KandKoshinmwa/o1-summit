// Nova fuel-stop recommendation engine.
// Uses mocked station + price data so the API contract is real even though
// Google Maps + TinyFish integrations are not wired yet.
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

interface Station {
  id: string;
  name: string;
  brand: string;
  price_per_gallon: number;
  distance_miles: number;
  detour_minutes: number;
  has_rewards: boolean;
  rewards_per_gallon: number;
  amenity_score: number; // 0-100
}

const MOCK_STATIONS: Station[] = [
  { id: "stn_chevron", name: "Chevron — Main St", brand: "Chevron", price_per_gallon: 3.89, distance_miles: 0.3, detour_minutes: 2, has_rewards: true, rewards_per_gallon: 0.05, amenity_score: 70 },
  { id: "stn_shell", name: "Shell — 5th Ave", brand: "Shell", price_per_gallon: 3.82, distance_miles: 1.1, detour_minutes: 5, has_rewards: false, rewards_per_gallon: 0, amenity_score: 65 },
  { id: "stn_76", name: "76 — Highway 1", brand: "76", price_per_gallon: 4.02, distance_miles: 1.2, detour_minutes: 6, has_rewards: false, rewards_per_gallon: 0, amenity_score: 50 },
  { id: "stn_costco", name: "Costco Gas", brand: "Costco", price_per_gallon: 3.71, distance_miles: 2.4, detour_minutes: 9, has_rewards: false, rewards_per_gallon: 0, amenity_score: 80 },
  { id: "stn_arco", name: "ARCO — Industrial", brand: "ARCO", price_per_gallon: 3.78, distance_miles: 1.6, detour_minutes: 7, has_rewards: false, rewards_per_gallon: 0, amenity_score: 40 },
];

async function enrichWithTinyFish(
  stations: Station[],
  near: string,
  fuelType: string,
): Promise<{ stations: Station[]; livePriceCount: number }> {
  const apiKey = Deno.env.get("TINYFISH_API_KEY");
  if (!apiKey) return { stations, livePriceCount: 0 };

  const base = Deno.env.get("TINYFISH_API_BASE") ?? "https://api.tinyfish.io/v1";
  try {
    const url = new URL(`${base}/fuel-prices`);
    url.searchParams.set("location", near);
    url.searchParams.set("fuel_type", fuelType);
    const res = await fetch(url.toString(), {
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Accept": "application/json",
      },
    });
    if (!res.ok) {
      console.warn("TinyFish non-OK:", res.status);
      return { stations, livePriceCount: 0 };
    }
    const payload = (await res.json()) as {
      stations?: Array<{ brand?: string; name?: string; price?: number; price_per_gallon?: number }>;
    };
    const live = payload.stations ?? [];
    if (live.length === 0) return { stations, livePriceCount: 0 };

    let count = 0;
    const merged = stations.map((s) => {
      const match = live.find(
        (l) =>
          (l.brand && l.brand.toLowerCase() === s.brand.toLowerCase()) ||
          (l.name && s.name.toLowerCase().includes(l.name.toLowerCase())),
      );
      const p = match?.price_per_gallon ?? match?.price;
      if (typeof p === "number" && Number.isFinite(p) && p > 0) {
        count += 1;
        return { ...s, price_per_gallon: Math.round(p * 100) / 100 };
      }
      return s;
    });
    return { stations: merged, livePriceCount: count };
  } catch (e) {
    console.warn("TinyFish error:", (e as Error).message);
    return { stations, livePriceCount: 0 };
  }
}

interface ScoredStation {
  station: Station;
  total_cost: number;
  estimated_savings: number;
  score: number;
  reasoning: string;
}

interface RequestBody {
  origin: string;
  destination: string;
  fleetId?: string | null;
  fillGallons?: number;
}

function score(stations: Station[], opts: {
  prefCost: number;
  prefTime: number;
  prefQuality: number;
  fillGallons: number;
}): ScoredStation[] {
  const { prefCost, prefTime, prefQuality, fillGallons } = opts;
  const total = Math.max(1, prefCost + prefTime + prefQuality);
  const wC = prefCost / total;
  const wT = prefTime / total;
  const wQ = prefQuality / total;

  const effective = (s: Station) =>
    s.has_rewards ? s.price_per_gallon - s.rewards_per_gallon : s.price_per_gallon;
  const maxEff = Math.max(...stations.map(effective));
  const minEff = Math.min(...stations.map(effective));
  const maxDetour = Math.max(...stations.map((s) => s.detour_minutes), 1);

  return stations
    .map((s) => {
      const eff = effective(s);
      const fuelCost = eff * fillGallons;
      const detourCost = s.detour_minutes * 0.25;
      const totalCost = fuelCost + detourCost;
      const baselineCost = maxEff * fillGallons;
      const estimatedSavings = Math.max(0, baselineCost - fuelCost);

      const costScore = 100 * (1 - (eff - minEff) / Math.max(0.01, maxEff - minEff));
      const timeScore = 100 * (1 - s.detour_minutes / maxDetour);
      const qualityScore = s.amenity_score;

      const composite = wC * costScore + wT * timeScore + wQ * qualityScore;
      const reasoning = buildReasoning(s, eff, wC, wT, wQ);

      return {
        station: s,
        total_cost: Math.round(totalCost * 100) / 100,
        estimated_savings: Math.round(estimatedSavings * 100) / 100,
        score: Math.round(composite * 10) / 10,
        reasoning,
      };
    })
    .sort((a, b) => b.score - a.score);
}

function buildReasoning(s: Station, eff: number, wC: number, wT: number, wQ: number): string {
  const parts: string[] = [];
  parts.push(`$${eff.toFixed(2)}/gal`);
  parts.push(`${s.detour_minutes} min detour`);
  if (s.has_rewards) parts.push(`rewards −$${s.rewards_per_gallon.toFixed(2)}`);
  const dominant =
    wC >= wT && wC >= wQ ? "cost" : wT >= wQ ? "time" : "quality";
  return `Best on ${dominant}: ${parts.join(" • ")}.`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("authorization")?.replace("Bearer ", "");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = (await req.json()) as RequestBody;
    const fillGallons = body.fillGallons ?? 12;

    const { data: profile } = await supabase
      .from("user_profiles")
      .select("pref_cost,pref_time,pref_quality,fuel_efficiency_mpg,fuel_type")
      .eq("user_id", user.id)
      .maybeSingle();

    // Server-side fleet derivation: find the user's fleet from membership or
    // ownership rather than trusting the client. Closes the bypass where a
    // client could omit fleetId to dodge the paywall.
    let fleetIdForUser: string | null = null;
    const { data: memberRow } = await supabase
      .from("fleet_members")
      .select("fleet_id")
      .eq("user_id", user.id)
      .maybeSingle();
    if (memberRow?.fleet_id) {
      fleetIdForUser = memberRow.fleet_id;
    } else {
      const { data: ownedFleet } = await supabase
        .from("fleets")
        .select("id")
        .eq("owner_user_id", user.id)
        .maybeSingle();
      fleetIdForUser = ownedFleet?.id ?? null;
    }

    if (fleetIdForUser) {
      const { data: hasSub } = await supabase.rpc("fleet_has_active_subscription", {
        _fleet_id: fleetIdForUser,
      });
      if (!hasSub) {
        return new Response(
          JSON.stringify({
            error: "FLEET_INACTIVE",
            message: "This fleet has no active Nova Fleet Pro subscription.",
          }),
          {
            status: 402,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }
    }

    const { stations: enriched, livePriceCount } = await enrichWithTinyFish(
      MOCK_STATIONS,
      body.destination ?? body.origin ?? "",
      profile?.fuel_type ?? "regular",
    );

    const ranked = score(enriched, {
      prefCost: profile?.pref_cost ?? 50,
      prefTime: profile?.pref_time ?? 50,
      prefQuality: profile?.pref_quality ?? 50,
      fillGallons,
    });
    const best = ranked[0];

    const { data: recRow } = await supabase
      .from("recommendations")
      .insert([
        {
          driver_user_id: user.id,
          fleet_id: fleetIdForUser,
          origin: body.origin,
          destination: body.destination,
          recommended_route: { origin: body.origin, destination: body.destination },
          recommended_fuel_stop: best.station as never,
          ranked_stations: ranked as never,
          estimated_savings_usd: best.estimated_savings,
          score: best.score,
          status: "pending",
        },
      ])
      .select()
      .single();

    return new Response(
      JSON.stringify({
        recommendation_id: recRow?.id ?? null,
        ranked,
        best,
        meta: {
          used_profile: !!profile,
          mpg: profile?.fuel_efficiency_mpg ?? null,
          live_price_count: livePriceCount,
          fleet_id: fleetIdForUser,
          weights: {
            cost: profile?.pref_cost ?? 50,
            time: profile?.pref_time ?? 50,
            quality: profile?.pref_quality ?? 50,
          },
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
