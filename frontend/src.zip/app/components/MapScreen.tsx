import { Navigation, Star, MapPin, X, TrendingDown, Filter, DollarSign, Clock } from 'lucide-react';
import { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import Button from './shared/Button';
import Card from './shared/Card';

interface StationWithMeta {
  id: number;
  name: string;
  price: number;
  distance: string;
  distanceMiles: number;
  detourMinutes: number;
  hasRewards: boolean;
  rewardsAmount?: number;
  position: { x: number; y: number };
  priceLevel?: 'cheap' | 'moderate' | 'expensive';
  isOptimal?: boolean;
}

export default function MapScreen() {
  const { stations: contextStations, getPriceLevel, getEffectivePrice, getOptimalRecommendation, isFleetManager } = useAppContext();
  const [showFilters, setShowFilters] = useState(false);
  const [selectedStation, setSelectedStation] = useState<StationWithMeta | null>(null);

  // Fleet Managers do not have access to station-level views
  if (isFleetManager()) {
    return (
      <div className="flex flex-col items-center justify-center p-6 h-full">
        <Card>
          <div className="text-center py-8">
            <MapPin size={48} className="text-[#A3ADC0] mx-auto mb-4" />
            <h2 className="text-[18px] font-semibold text-[#0B132B] mb-2 leading-[1.3]">Access Restricted</h2>
            <p className="text-[14px] text-[#5F6C7B] leading-[1.5]">
              Fleet Managers do not have access to individual station comparisons or route recommendations.
            </p>
            <p className="text-[13px] text-[#5F6C7B] mt-3 leading-[1.5]">
              View fleet-level analytics via Fleet Insights instead.
            </p>
          </div>
        </Card>
      </div>
    );
  }

  const optimalRec = getOptimalRecommendation();

  const stations: StationWithMeta[] = contextStations.map(station => ({
    ...station,
    priceLevel: getPriceLevel(getEffectivePrice(station)),
    isOptimal: optimalRec.station.id === station.id,
  }));

  const getPriceColor = (level?: 'cheap' | 'moderate' | 'expensive') => {
    switch (level) {
      case 'cheap':
        return 'bg-[#10B981]';
      case 'moderate':
        return 'bg-[#F59E0B]';
      case 'expensive':
        return 'bg-[#B3261E]';
      default:
        return 'bg-[#A3ADC0]';
    }
  };

  return (
    <div className="flex flex-col h-full relative">
      {/* Header */}
      <div className="absolute top-4 left-4 right-4 z-10 flex gap-2">
        <div className="flex-1 bg-white border border-[#E9EDF5] rounded-xl px-4 py-3 shadow-md">
          <div className="flex items-center gap-2">
            <TrendingDown size={18} className="text-[#3E5C9A]" />
            <span className="text-[14px] font-semibold text-[#0B132B] leading-[1.4]">Fuel Stations Near You</span>
          </div>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="bg-white border border-[#E9EDF5] rounded-xl px-4 py-3 shadow-md hover:bg-[#F7F8FA] transition-colors"
        >
          <Filter size={18} className="text-[#5F6C7B]" />
        </button>
      </div>

      {/* Map View */}
      <div className="flex-1 relative bg-[#E9EDF5]">
        {/* Map Placeholder */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-xs text-[#A3ADC0]">[Map View]</div>
        </div>

        {/* Map Grid Lines */}
        <div className="absolute inset-0 opacity-10">
          <div className="w-full h-full grid grid-cols-4 grid-rows-4">
            {[...Array(16)].map((_, i) => (
              <div key={i} className="border border-[#A3ADC0]" />
            ))}
          </div>
        </div>

        {/* Route Line */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <path
            d="M 50 80 Q 60 60, 70 40"
            stroke="#3E5C9A"
            strokeWidth="3"
            strokeDasharray="8,4"
            fill="none"
            opacity="0.6"
          />
        </svg>

        {/* User Location */}
        <div
          className="absolute w-4 h-4 bg-[#6A7FDB] border-2 border-white rounded-full shadow-lg"
          style={{ left: '50%', top: '80%', transform: 'translate(-50%, -50%)' }}
        >
          <div className="absolute inset-0 bg-[#6A7FDB] rounded-full animate-ping opacity-75" />
        </div>

        {/* Destination (Work) */}
        <div
          className="absolute"
          style={{ left: '70%', top: '40%', transform: 'translate(-50%, -50%)' }}
        >
          <div className="w-8 h-8 bg-[#0B132B] rounded-full flex items-center justify-center">
            <MapPin size={16} className="text-white" />
          </div>
        </div>

        {/* Fuel Stations */}
        {stations.map((station) => (
            <button
              key={station.id}
              onClick={() => setSelectedStation(station)}
              className="absolute group"
              style={{
                left: `${station.position.x}%`,
                top: `${station.position.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              {/* Optimal Pulse */}
              {station.isOptimal && (
                <div className="absolute inset-0 w-12 h-12 -ml-6 -mt-6">
                  <div className="absolute inset-0 bg-[#3E5C9A] rounded-full animate-ping opacity-40" />
                </div>
              )}

              {/* Station Marker */}
              <div
                className={`relative ${
                  station.isOptimal
                    ? 'w-12 h-12 border-4 border-[#3E5C9A] shadow-xl'
                    : 'w-10 h-10 border-2 border-white shadow-lg'
                } ${getPriceColor(station.priceLevel)} rounded-full flex items-center justify-center transition-transform group-hover:scale-110`}
              >
                <span className="text-white text-xs font-medium">
                  ${getEffectivePrice(station).toFixed(2)}
                </span>
                {station.hasRewards && (
                  <Star
                    size={10}
                    className="absolute -top-1 -right-1 text-[#F59E0B] fill-[#F59E0B]"
                  />
                )}
              </div>

              {/* Station Label */}
              <div className="absolute top-full mt-1 left-1/2 -translate-x-1/2 whitespace-nowrap">
                <div className="bg-white px-2 py-1 rounded-lg text-[12px] font-medium shadow-md border border-[#E9EDF5] leading-[1.4]">
                  {station.name}
                </div>
              </div>
            </button>
          ))}
      </div>

      {/* Legend */}
      {!selectedStation && (
        <Card className="absolute bottom-24 right-4 shadow-lg" padding="sm">
          <div className="text-[12px] font-medium text-[#0B132B] mb-2 leading-[1.4]">Price Levels</div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-[#10B981] rounded-full" />
              <span className="text-[12px] text-[#5F6C7B] leading-[1.4]">Under $3.90</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-[#F59E0B] rounded-full" />
              <span className="text-[12px] text-[#5F6C7B] leading-[1.4]">$3.90 - $4.10</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-[#B3261E] rounded-full" />
              <span className="text-[12px] text-[#5F6C7B] leading-[1.4]">Over $4.10</span>
            </div>
          </div>
        </Card>
      )}

      {/* Station Detail Sheet */}
      {selectedStation && (
        <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl border-t-2 border-[#E9EDF5] p-6 animate-slide-up">
          <button
            onClick={() => setSelectedStation(null)}
            className="absolute top-4 right-4 text-[#A3ADC0] hover:text-[#0B132B] transition-colors"
          >
            <X size={20} />
          </button>

          <div className="mb-4">
            {selectedStation.isOptimal && (
              <div className="inline-block bg-[#3E5C9A] text-white text-[11px] font-semibold px-2.5 py-1 rounded uppercase mb-3 leading-[1.4]">
                Optimal Decision
              </div>
            )}

            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h3 className="text-[24px] font-semibold text-[#0B132B] mb-1 leading-[1.3]">{selectedStation.name}</h3>
                <div className="flex items-center gap-3 text-[13px] text-[#5F6C7B] leading-[1.5]">
                  <div className="flex items-center gap-1">
                    <MapPin size={14} />
                    <span>{selectedStation.distance} away</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock size={14} />
                    <span>{selectedStation.detourMinutes} min detour</span>
                  </div>
                </div>
              </div>
              <div className="text-right ml-3">
                <div className="text-[32px] font-semibold text-[#0B132B] mb-1 leading-[1.2]">
                  ${getEffectivePrice(selectedStation).toFixed(2)}
                </div>
                <div className="text-[12px] text-[#5F6C7B] leading-[1.4]">per gallon</div>
              </div>
            </div>

            {selectedStation.hasRewards && (
              <Card variant="success" padding="sm" className="mb-3">
                <div className="flex items-center gap-2 text-[13px] text-[#0B132B] leading-[1.4]">
                  <Star size={14} className="text-[#F59E0B] fill-[#F59E0B]" />
                  <span>
                    Save ${selectedStation.rewardsAmount?.toFixed(2)}/gal with rewards program
                  </span>
                </div>
              </Card>
            )}

            {selectedStation.isOptimal && (
              <Card variant="info" padding="sm" className="mb-3">
                <div className="text-[13px] font-semibold text-[#0B132B] mb-1 leading-[1.4]">Why this is optimal for you</div>
                <div className="text-[13px] text-[#5F6C7B] leading-[1.5]">
                  {optimalRec.reasoning}
                </div>
              </Card>
            )}

            {/* Total Cost Breakdown */}
            {selectedStation.isOptimal && (
              <div className="bg-[#F7F8FA] rounded-lg p-3 mb-3">
                <div className="text-[12px] font-medium text-[#0B132B] mb-2 leading-[1.4]">Weekly Cost Breakdown</div>
                <div className="grid grid-cols-3 gap-2 text-center mb-2">
                  <div>
                    <div className="text-[14px] font-semibold text-[#0B132B] leading-[1.3]">
                      ${optimalRec.breakdown.fuelCost.toFixed(2)}
                    </div>
                    <div className="text-[10px] text-[#5F6C7B] leading-[1.4]">Fuel</div>
                  </div>
                  <div>
                    <div className="text-[14px] font-semibold text-[#0B132B] leading-[1.3]">
                      ${optimalRec.breakdown.timeCost.toFixed(2)}
                    </div>
                    <div className="text-[10px] text-[#5F6C7B] leading-[1.4]">Time</div>
                  </div>
                  <div>
                    <div className="text-[14px] font-semibold text-[#0B132B] leading-[1.3]">
                      ${optimalRec.breakdown.detourCost.toFixed(2)}
                    </div>
                    <div className="text-[10px] text-[#5F6C7B] leading-[1.4]">Detour</div>
                  </div>
                </div>
                <div className="border-t border-[#E9EDF5] pt-2 flex items-center justify-between">
                  <span className="text-[12px] text-[#5F6C7B] leading-[1.4]">Total weekly cost</span>
                  <span className="text-[16px] font-semibold text-[#0B132B] leading-[1.3]">
                    ${optimalRec.totalCost.toFixed(2)}
                  </span>
                </div>
              </div>
            )}
          </div>

          <Button variant="primary" fullWidth size="lg" className="flex items-center justify-center gap-2">
            <Navigation size={18} />
            Navigate to {selectedStation.name}
          </Button>
        </div>
      )}
    </div>
  );
}
